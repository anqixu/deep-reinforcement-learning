This implementation of PyTorch SAC originated from https://github.com/pranz24/pytorch-soft-actor-critic.
I modified some parts of the codebase.